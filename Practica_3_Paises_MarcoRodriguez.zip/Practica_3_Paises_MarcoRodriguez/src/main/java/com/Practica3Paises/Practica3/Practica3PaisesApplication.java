package com.Practica3Paises.Practica3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica3PaisesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica3PaisesApplication.class, args);
	}

}
